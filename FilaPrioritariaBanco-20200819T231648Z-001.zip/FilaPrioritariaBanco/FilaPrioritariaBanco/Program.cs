﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Security.Cryptography.X509Certificates;

namespace FilaPrioritariaBanco
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue geral = new Queue();
            Queue prioritario = new Queue();

            int controle;
            int n = 0;
            int n2 = 0;
            int var = 110;

            int var2 = 0;
            int i;

            {
                Console.WriteLine("------- Selecione o Atendimento ----------");
                Console.WriteLine("\n 1 - Geral");
                Console.WriteLine("\n 2 - Prioritario");

                controle = Convert.ToInt32(Console.ReadLine());

                if (controle == 1)
                {
                    geral.Enqueue(n);
                    n++;
                    var2++;
                }

                else if (controle == 2)
                {
                    prioritario.Enqueue(n2);
                    n2++;
                    var2++;
                }

                if(var2 == 10)
                {
                    var = 0;
                }

            }while (var != 0) ;

            Console.WriteLine("\n ------FILA------");
            Console.WriteLine("\n PRIORITARIOS"):

            for(i = 0; i<n; i++)
            {
                Console.WriteLine("\n CXP-")
            }

        }
    }
}
