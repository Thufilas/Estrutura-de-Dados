﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace FilaPrioritariaBanco
{
    class Fila
    {

        Queue geral = new Queue();
        Queue prioritario = new Queue();




    }
}
